using EX_2_3;
using System.Collections.Generic;

namespace EX_2_3
{
	public class Avaliador : Funcionario
	{
		private ICollection<AtividadeFuncionario> avaliacao;

		private Avaliador avaliador;

		private Avaliador avaliador;

	}

}

