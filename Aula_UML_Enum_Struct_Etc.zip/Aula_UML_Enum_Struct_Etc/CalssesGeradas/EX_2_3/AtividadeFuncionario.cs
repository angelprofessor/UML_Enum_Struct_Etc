using EX_2_3;
using System.Collections.Generic;

namespace EX_2_3
{
	public class AtividadeFuncionario
	{
		private Funcionario funcionario;

		private Atividade atividade;

		private ICollection<Avaliador> avaliacao;

	}

}

