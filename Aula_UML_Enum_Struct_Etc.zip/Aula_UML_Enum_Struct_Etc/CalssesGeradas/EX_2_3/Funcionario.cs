using System.Collections.Generic;
using EX_2_3;

namespace EX_2_3
{
	public class Funcionario
	{
		public string NomeFuncionario{ get; set; }

		public int CPF{ get; set; }

		private ICollection<Atividade> atividadeFuncionario;

		private ICollection<Funcionario> Subordinado;

		private Funcionario Gerente;

	}

}

