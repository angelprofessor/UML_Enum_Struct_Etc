using System.Collections.Generic;
using EX_2_3;

namespace EX_2_3
{
	public class Atividade
	{
		public string NomeAtividade{ get; set; }

		private Atividade atividade;

		private Atividade atividade;

		private ICollection<Funcionario> atividadeFuncionario;

	}

}

