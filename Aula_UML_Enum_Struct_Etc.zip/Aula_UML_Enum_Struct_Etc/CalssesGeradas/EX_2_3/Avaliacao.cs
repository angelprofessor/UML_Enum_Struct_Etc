using EX_2_3;

namespace EX_2_3
{
	public class Avaliacao
	{
		private Avaliador avaliador;

		private AtividadeFuncionario atividadeFuncionario;

	}

}

