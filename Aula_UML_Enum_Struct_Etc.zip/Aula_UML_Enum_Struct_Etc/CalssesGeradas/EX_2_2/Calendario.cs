using EX_2_2;
using System.Collections.Generic;

namespace EX_2_2
{
	public class Calendario
	{
		public DateTime Data{ get; set; }

		private Programa programa;

		private ICollection<Programa> programacao;

	}

}

