using EX_2_2;
using System.Collections.Generic;

namespace EX_2_2
{
	public class Programa
	{
		public string NomeDoPrograma{ get; set; }

		public DateTime Duracao{ get; set; }

		public int FaixaEtaria{ get; set; }

		private Calendario calendario;

		private ICollection<Calendario> programacao;

		private TipoPrograma tipoPrograma;

	}

}

