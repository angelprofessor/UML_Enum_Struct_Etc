using System.Collections.Generic;
using EX_2_2;

namespace EX_2_2
{
	public class TipoPrograma
	{
		public string NomeTipo{ get; set; }

		public int FaixaEtaria{ get; set; }

		private ICollection<Programa> programa;

	}

}

