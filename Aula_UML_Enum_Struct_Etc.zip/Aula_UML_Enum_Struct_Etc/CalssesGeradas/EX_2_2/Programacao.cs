using EX_2_2;

namespace EX_2_2
{
	public class Programacao
	{
		public float HoraInicio{ get; set; }

		private Calendario calendario;

		private Programa programa;

	}

}

