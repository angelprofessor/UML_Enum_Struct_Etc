using System.Collections.Generic;
using EX_2_1;

namespace EX_2_1
{
	public class Artista
	{
		public string Nome{ get; set; }

		public string HomePage{ get; set; }

		private ICollection<Filme> filme;

		private ICollection<Filme> filme;

	}

}

