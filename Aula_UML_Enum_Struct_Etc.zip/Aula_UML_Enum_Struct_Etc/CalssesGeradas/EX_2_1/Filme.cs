using System.Collections.Generic;
using EX_2_1;

namespace EX_2_1
{
	public class Filme
	{
		public int NumeroFilme{ get; set; }

		public string TituloFilme{ get; set; }

		public int AnoProducao{ get; set; }

		public double Duracao{ get; set; }

		private Filme filme;

		private Filme filme;

		private ICollection<Artista> artista;

		private ICollection<Artista> artista;

		private Genero genero;

		private Pais pais;

	}

}

