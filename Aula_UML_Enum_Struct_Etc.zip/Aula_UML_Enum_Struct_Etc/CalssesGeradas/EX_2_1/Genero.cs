using System.Collections.Generic;
using EX_2_1;

namespace EX_2_1
{
	public class Genero
	{
		public string GeneroFilma{ get; set; }

		private ICollection<Filme> filme;

	}

}

