using System.Collections.Generic;
using EX_2_1;

namespace EX_2_1
{
	public class Pais
	{
		public string NomePais{ get; set; }

		private ICollection<Filme> filme;

	}

}

