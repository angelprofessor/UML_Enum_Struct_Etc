﻿using System;
namespace EE7
{
    public struct Condomino
    {
        private string Nome;
        private double Mensalidade;
        private bool Pagou;
        public Condomino(string N, double M)//CONTRUTOR
        {
            Nome = N;
            Mensalidade = M;
            Pagou = false;
        }
        public Condomino(string N, double M, bool P)//CONTRUTOR
        {
            Nome = N;
            Mensalidade = M;
            Pagou = P;
        }
        public string PNome //PROPRIEDADE
        {
            get
                { return Nome; }
            set
                { Nome = value; }
        }
        public double PMensal //PROPRIEDADE
        {
            get
            { return Mensalidade; }
            set
            { Mensalidade = value; }
        }
        public bool PPagou  //PROPRIEDADE
        {
            get
            { return Pagou; }
            set
            { Pagou = value; }
        }
        public override string ToString() //SOBRE  ESCRITA
        {
            string R = "";
            if (Pagou == false)
                R = String.Format("O condómino {0} tem {1} euros deste mês  por pagar ", Nome, Mensalidade);
            else
                R = String.Format("O condómino {0} já pagou {1} euros ",
                Nome, Mensalidade);
            return R;
        }
    }
    public class Condominios
    {
        static void Main(string[] args)
        {
            Condomino C = new Condomino("A. Ruelas", 140);
            Console.WriteLine(C.ToString());
            C = new Condomino("B. Brochado", 120, true);
            Console.WriteLine(C.ToString());
        }
    }
}
