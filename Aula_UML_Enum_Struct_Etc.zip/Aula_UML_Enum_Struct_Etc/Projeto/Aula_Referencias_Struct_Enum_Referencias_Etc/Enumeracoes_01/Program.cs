﻿using System;
namespace EE1
{
    public class SubAlfabeto
    {
        enum Letras : int { B = 66, P = 80, Passo = 2 };
        static void Main(string[] args)
        {
            string Subalfabeto = "";
            for (int I = (int)Letras.B; I <= (int)Letras.P;
            I += (int)Letras.Passo)
            { Subalfabeto += (char)I; }
            Console.WriteLine(Subalfabeto);
        }
    }
}
