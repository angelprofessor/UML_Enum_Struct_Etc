﻿using System;
namespace EE3
{
    public class TotaisMensais
    {
        enum Meses { Jan = 0, Fev, Mar, Abr, Mai, Jun, Jul, Ago, Set, Out, Nov, Dez };
        static void Main(string[] args)
        {
            double[] Vendas ={1000,1200,500,300,400,600,700,800,900,1000,
1200,2000};
            double Soma = 0;
            for (int i = (int)Meses.Mai; i <= (int)Meses.Ago; i++)
            { Soma += Vendas[i]; }
            Console.WriteLine("Total de Vendas de {0} a {1}={2}",
            Meses.Mai, Meses.Ago, Soma);
        }
    }
}
