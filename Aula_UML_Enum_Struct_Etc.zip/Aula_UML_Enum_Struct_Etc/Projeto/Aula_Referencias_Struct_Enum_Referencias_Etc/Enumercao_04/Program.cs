﻿using System;
namespace EE4
{
    public class MenuOpcoes
    {
        enum Bebidas
        {
            Chá = 1,
            Café = 2,
            Água = 3,
            Laranjada = 6,
            CocaCola = 7,
            Porto = 4,
            Champanhe = 5
        };
        static void Main(string[] args)
        {
            int Opcao = 0;
            Bebidas[] Menu = new Bebidas[4];
            for (int i = 0; i <= 3; i++)
                Menu[i] = (Bebidas)i + 1;
            do
            {
                Console.Clear();
                foreach (Bebidas Op in Menu)
                    Console.WriteLine((int)Op + ". " + Op.ToString());
                Console.Write("Qual a sua opção? ");
                Opcao = Convert.ToInt16(Console.ReadLine());
            } while (Opcao < 1 || Opcao > Menu.Length);
            Console.WriteLine("Escolheu " + (Bebidas)Opcao);
        }
    }
}
