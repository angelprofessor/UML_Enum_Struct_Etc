﻿using System;
namespace EE8
{
    public struct Condomino
    {
        private string Nome;
        private double Mensalidade;
        private bool Pagou;
        public Condomino(string N, double M)
        {
            Nome = N;
            Mensalidade = M;
            Pagou = false;
        }
        public Condomino(string N, double M, bool P)
        {
            Nome = N;
            Mensalidade = M;
            Pagou = P;
        }
        public string PNome
        {
            get
            { return Nome; }
            set
            { Nome = value; }
        }
        public double PMensal
        {
            get
            { return Mensalidade; }
            set
            { Mensalidade = value; }
        }
        public bool PPagou
        {
            get
            { return Pagou; }
            set
            { Pagou = value; }
        }
        public override string ToString()
        {
            string R = "";
            if (Pagou == false)
                R = String.Format("O condómino {0} tem {1} deste mês por pagar ", Nome, Mensalidade);
            else
                R = String.Format("O condómino {0} já pagou {1} ", Nome,
                Mensalidade);
            return R;
        }
    }
    public class PorCobrar
    {
        static void Main(string[] args)
        {
            string N; double M; bool P;
            Console.Write("Número de condóminos ");
            int Ncond = Convert.ToInt16(Console.ReadLine());
            Condomino[] C = new Condomino[Ncond];//MATRIZ  DE STRTUCTS
            for (int I = 0; I <= C.Length - 1; I++)
            {
                Console.Write("Nome do condómino ");
                N = Console.ReadLine();
                Console.Write("Mensalidade ");
                M = Convert.ToDouble(Console.ReadLine());
                Console.Write("Pagou (True or False)");
                P = Convert.ToBoolean(Console.ReadLine());
                C[I] = new Condomino(N, M, P);
            }
            double Tot = 0;
            for (int I = 0; I <= C.Length - 1; I++)
                if (C[I].PPagou == false)
                    Tot += C[I].PMensal;
            Console.WriteLine("Montante a cobrar {0} euros ", Tot);
        }
    }
}
