﻿using System;
namespace EE2
{
    public class HorarioSemanal
    {
        enum Semana
        {
            Domingo = 1,
            Segunda,
            Terça,
            Quarta,
            Quinta,
            Sexta,
            Sábado
        };
        static void Main(string[] args)
        {
            for (int D = (int)Semana.Domingo; D <= (int)Semana.Sábado; D++)
            {
                if (D % 2 == 0)
                    Console.WriteLine("{0} - {1}", (Semana)D, "Ginástica");
                else
                    Console.WriteLine("{0} - {1}", (Semana)D, "Ioga");
            }
        }
    }
}
