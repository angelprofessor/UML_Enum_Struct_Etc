﻿using System;
namespace PF4
{
    class RefeOut
    {
        static void PotRef(ref double X, int Expoente)
        { X = Math.Pow(X, Expoente); }
        static void PotOut(out double Z, int Expoente)
        {
            Z = 3;
            Z = Math.Pow(Z, 3);
        }
        static void Main(string[] args)
        {
            //QUASO SE USA REF  O  VALOR  PRECISA  SER INICISALIZADO  ANTES
            //DE SER  PASSADO
            double X = 4; //PASSADO POR  REFERENCIA            
            int Expoente = 3;//PASSADO POR  VALOR
            //QUASO SE USA OUT  A  VARIAVEL  NAOOOO  PRECISA  SER INICISALIZADA  ANTES
            //DE SER  PASSADA, MAS  PRECISA  RECEBER UM VALOR DENTRO DO  METODO  CHAMADO
            double Z;//PASSADO POR  REFERENCIA
            Console.WriteLine("Valor original de X={0}", X);
            Console.WriteLine("Z não foi inicializado");
            Console.WriteLine("Valor original do expoente={0}", Expoente);
            PotRef(ref X, Expoente);
            PotOut(out Z, Expoente);
            Console.WriteLine("X levantado ao expoente={0}", X);
            Console.WriteLine("Z levantado ao expoente={0}", Z);
            Console.WriteLine("Valor final de X={0}", X);
            Console.WriteLine("Valor final de Z={0}", Z);
            Console.WriteLine("Valor final do expoente={0}", Expoente);
        }
    }
}