﻿using System;
namespace EE6
{
    public struct ColegasS
    {
        private string Nome;
        public string PNome
        {
            get
            { return Nome; }
            set
            { Nome = value; }
        }
    }
    public class ColegasC
    {
        private string Nome;
        public ColegasC(string N)
        { Nome = N; }
        public string PNome
        {
            get
            { return Nome; }
            set
            { Nome = value; }
        }
        public class ValorEReferencia
        {
            static void Main(string[] args)
            {
                ColegasS S = new ColegasS();
                S.PNome = "Joana Silva";
                ColegasS S1 = S;
                S1.PNome = "Rui Alves";
                Console.WriteLine("Nomes de S e S1: {0} e {1} ", S.PNome,
                S1.PNome);
                ColegasC C = new ColegasC("Teresa Pinto");
                ColegasC C1 = C;
                C1.PNome = "Pedro Moita";
                Console.WriteLine("Nomes de C e C1: {0} e {1}", C.PNome,
                C1.PNome);
            }
        }
    }
}

