﻿using System;
namespace PF3
{ 
    class TracaDeValores
    {
        static void Troca(ref string X, ref string Y)
        {
            string Temporaria;
            Temporaria = X;
            X = Y;
            Y = Temporaria;
        }
        static void Main(string[] args)
        {
            string X, Y;
            Console.Write("Digite o valor da primeira variavel (X) ");
            X = Console.ReadLine();
            Console.Write("Digite o valor da segunda variavel (Y) ");
            Y = Console.ReadLine();
            Troca(ref X, ref Y);
            Console.WriteLine("X= {0}", X);
            Console.WriteLine("Y= {0}", Y);
        }
    }
}