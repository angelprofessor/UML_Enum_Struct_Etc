using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Unario
{
	public class Funcionario
	{
		long Codigo;
		string Nome;
		string Cargo;
		Funcionario Gerente;

		public Funcionario CosultaFuncionario(long Codigo)
		{
			throw new NotImplementedException();
		}

		public Funcionario ConsultaChefe(long Codigo)
		{
			throw new NotImplementedException();
		}
	}
}
