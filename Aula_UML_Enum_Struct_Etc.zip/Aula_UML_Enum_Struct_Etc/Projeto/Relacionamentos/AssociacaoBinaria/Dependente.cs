using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.AssociacaoBinaria
{
	public class Dependente
	{
		string NomeDependente;
		DateTime DataNascimento;
	}
}
