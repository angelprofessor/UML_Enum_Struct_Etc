using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.AssociacaoBinaria
{
	public class Socio
	{
		string NomeSocio;
		string Endereco;
		string Telefone;

		public int Registrar()
		{
			throw new NotImplementedException();
		}

		public int Consultar()
		{
			throw new NotImplementedException();
		}
	}
}
