using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.ApoliceSeguros
{
	public class Cliente
	{
		string Nome;
		string Endereco;
		string Relefone;
		DateTime DataNascimento;
		VeiculoSegurado[] Veiculos;

		public int Consultar()
		{
			throw new NotImplementedException();
		}

		public int Registrar()
		{
			throw new NotImplementedException();
		}

		public int Excluir()
		{
			throw new NotImplementedException();
		}
	}
}
