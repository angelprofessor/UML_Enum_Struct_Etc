using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.ApoliceSeguros
{
	public class VeiculoSegurado
	{
		string Placa;
		long Kilometragem;
		DateTime DataApolice;
		DateTime Vigencia;
		double Valor;
		bool Dituacao;
		int NumeroApolice;
		Parcela[] Parcelas = new Parcela[4];

		public void Gerar()
		{
			throw new NotImplementedException();
		}

		public DateTime ConsultarVigencia(long NumeroApolice)
		{
			throw new NotImplementedException();
		}

		public bool CancelarApolice(long NumeroApolice)
		{
			throw new NotImplementedException();
		}
	}
}
