using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.ApoliceSeguros
{
	public class Sinistro
	{
		public long NumeroSinistro{get;set;}
		public DateTime DataSinistro{get;set;}
		public string Descricao{get;set;}

		public int Registrar()
		{
			throw new NotImplementedException();
		}

		public int Consultar()
		{
			throw new NotImplementedException();
		}
	}
}
