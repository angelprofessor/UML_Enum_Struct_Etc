using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.ApoliceSeguros
{
	public class Parcela
	{
		int numeroParcela;
		DateTime Vencimento;
		Decimal Valor;
		bool Quitacao;

		public DateTime ConsultarVecimentoParcela(int NumeroParcela)
		{
			throw new NotImplementedException();
		}

		public bool Quitar()
		{
			throw new NotImplementedException();
		}
	}
}
