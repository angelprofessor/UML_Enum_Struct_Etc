using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.ApoliceSeguros
{
	public class Modelo
	{
		public string NomeModelo{get;set;}
	}
}
