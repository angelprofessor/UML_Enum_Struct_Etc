using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Agregacao
{
	public class Curso
	{
		int Nome;
		int Codigo;
	}
}
