using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Agregacao
{
	public class Aluno
	{
		int Nome;
		string RA;
		Curso CursoMatriculado;
	}
}
