using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Agregacao2
{
	public class Disciplina
	{
		public int Nome{get;set;}
		public int Codigo{get;set;}
		public int CargaHoraria{get;set;}
	}
}
