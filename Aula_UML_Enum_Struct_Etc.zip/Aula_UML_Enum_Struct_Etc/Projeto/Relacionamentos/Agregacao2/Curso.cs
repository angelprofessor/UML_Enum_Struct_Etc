using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Agregacao2
{
	public class Curso
	{
		Disciplina[] Disciplinas;
		public string Nome{get;set;}
		public int Codigo{get;set;}

		public bool AdicionaDisciplina()
		{
			throw new NotImplementedException();
		}

		public bool RemoveDisciplina()
		{
			throw new NotImplementedException();
		}

		public Disciplina ConsultaDisciplina(int CodDisciplina)
		{
			throw new NotImplementedException();
		}
	}
}
