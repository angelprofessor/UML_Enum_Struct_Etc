using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Dependencia
{
	public class Aluno
	{
		string Nome;
		string RA;

		public bool Estudar(Livro isbn)
		{
			throw new NotImplementedException();
		}
	}
}
