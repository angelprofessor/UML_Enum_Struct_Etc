using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Dependencia
{
	public class Livro
	{
		string Titulo;
		string ISBN;
	}
}
