using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Composicao
{
	public class Aluno
	{
		Endereco Residencia;
		string RA;
		string Nome;
	}
}
