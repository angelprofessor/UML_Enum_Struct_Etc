using System;
using System.Collections.Generic;
using System.Text;

namespace Relacionamentos.Composicao
{
	public class Endereco
	{
		int Logradouro;
		int Numero;
		string Complemento;
		string CEP;
		string Cidade;
		string Estado;
	}
}
